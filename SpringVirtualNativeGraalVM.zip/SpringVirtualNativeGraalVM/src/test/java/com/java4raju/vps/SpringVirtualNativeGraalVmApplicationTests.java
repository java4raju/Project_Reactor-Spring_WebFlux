package com.java4raju.vps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringVirtualNativeGraalVmApplicationTests {

	@Test
	void contextLoads() {
	}

}
