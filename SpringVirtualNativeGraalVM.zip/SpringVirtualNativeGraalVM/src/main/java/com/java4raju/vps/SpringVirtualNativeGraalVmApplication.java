package com.java4raju.vps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringVirtualNativeGraalVmApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringVirtualNativeGraalVmApplication.class, args);
	}

}
